from django.contrib import admin
from .models import Codebin

admin.site.register(Codebin)
# Register your models here.
